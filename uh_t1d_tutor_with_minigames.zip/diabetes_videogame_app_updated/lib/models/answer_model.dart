class Answer {

  String text;
  int affectGlucose;
  int affectInTime;

  Answer({required this.text, required this.affectGlucose, required this.affectInTime});
}