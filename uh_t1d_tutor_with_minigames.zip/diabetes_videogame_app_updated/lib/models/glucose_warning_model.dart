import 'answer_model.dart';

enum WarningType { low, high, veryHigh }

class GlucoseWarning {
  WarningType type;
  String title;
  List<Answer> options;
  String correctOption;
  double time;

  GlucoseWarning({
    required this.type,
    required this.title,
    required this.options,
    required this.correctOption,
    required this.time,
  });

  String toString() {
    return "[time:${time}]";
  }
}
