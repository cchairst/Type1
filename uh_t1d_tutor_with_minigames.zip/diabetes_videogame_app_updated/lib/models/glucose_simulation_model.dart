import 'dart:convert';
import 'dart:math';

import 'package:fl_chart/fl_chart.dart';
import 'package:http/http.dart' as http;
import 'package:uh_t1d_tutor/controllers/patient_controller.dart';
import 'package:uh_t1d_tutor/models/answer_model.dart';
import 'package:uh_t1d_tutor/models/glucose_warning_model.dart';

import '../services/answers_for_warnings_service.dart';

class GlucoseSimulationModel {
  List<FlSpot> glucosePredictions = [];
  List<GlucoseWarning> warnings = [];
  List<Answer> answersForLowGlucose = [];
  String correctAnswerForLowGlucose = "";
  List<Answer> answersForVeryHighGlucose = [];
  String correctAnswerForVeryHighGlucose = "";
  List<Answer> answersForHighGlucose = [];
  String correctAnswerForHighGlucose = "";

  Future<void> init(PatientController patientController) async {
    glucosePredictions = [];
    warnings = [];
    answersForLowGlucose = await AnswersForWarnings().loadAnswers("low");
    answersForVeryHighGlucose = await AnswersForWarnings().loadAnswers(
      "veryHigh",
    );
    answersForHighGlucose = await AnswersForWarnings().loadAnswers("high");
    await generatePredictions();
    evaluateWarnings(patientController);
  }

  bool hasPredictions() {
    return glucosePredictions.isNotEmpty;
  }

  Future<List<dynamic>> fetchGlucosePredictions(String userId) async {
    final uri = Uri.parse('http://localhost:5050/api/glucosePrediction');
    final response = await http.post(
      uri,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'userId': userId,
        'chIntake': [
          [0, 30],
          [1, 2],
        ],
        'activity': [
          [0, 20, 20],
        ],
      }), // FIXME: this should be change to the actual user id.
    );
    if (response.statusCode == 200) {
      // Parses the JSON array of records into a List<dynamic>
      return jsonDecode(response.body) as List<dynamic>;
    } else {
      throw Exception(
        'Failed (${response.statusCode}): ${response.reasonPhrase}',
      );
    }
  }

  // X axis is based on the minutes from current time until the predicted value.
  Future<void> generatePredictions() async {
    glucosePredictions.add(FlSpot(0, 130.0));
    glucosePredictions.add(FlSpot(60, 100.0));
    glucosePredictions.add(FlSpot(120, 100.0));
    glucosePredictions.add(FlSpot(180, 120.0));
    glucosePredictions.add(FlSpot(240, 190.1));
    glucosePredictions.add(FlSpot(300, 125.1));

    /**
        glucosePredictions = [];
    // Request the glucose values.
    dynamic httpResponse = await fetchGlucosePredictions("1234");

    for (var prediction in httpResponse) {
      glucosePredictions.add(
        FlSpot(prediction["hours_from_now"], prediction["CGM"]),
      );
    }*/
  }

  void removeFistPrediction() {
    glucosePredictions.removeAt(0);
  }

  void applySelectedAnswerData(int affectGlucose, int affectInTime) {
    for (int x = 0; x < glucosePredictions.length; x++) {
      if (glucosePredictions[x].x.toInt() == affectInTime) {
        glucosePredictions[x] = FlSpot(
          glucosePredictions[x].x,
          glucosePredictions[x].y + affectGlucose.toDouble(),
        );
      }
    }
  }

  void shiftPredictionsLeft() {
    glucosePredictions =
        glucosePredictions.map((item) => FlSpot(item.x - 60, item.y)).toList();
  }

  void shiftWarningsLeft() {
    for (var warning in warnings) {
      warning.time = warning.time - 60;
    }
  }

  void generateNewPrediction() {
    // Get the last time predicted to calculate the next prediction time.
    num lastPredictedMinute =
        glucosePredictions.isNotEmpty ? glucosePredictions.last.x : -60;

    double max = 200.0;
    double min = 100.0;
    double randomValue = Random().nextDouble() * (max - min) + min;
    glucosePredictions.add(FlSpot(lastPredictedMinute + 60, randomValue));
  }

  void removeWarningIfIsFromFirstPrediction() {
    if (warnings.isNotEmpty && glucosePredictions.isNotEmpty) {
      if (warnings.first.time == glucosePredictions.first.x) {
        warnings.removeAt(0);
      }
    }
  }

  void removeFirstWarning() {
    if (warnings.isNotEmpty) warnings.removeAt(0);
  }

  void evaluateWarnings(PatientController patientController) {
    // Empty the list to evaluate new warnings.
    warnings.clear();

    for (FlSpot prediction in glucosePredictions) {
      if (prediction.y < patientController.patient.lowThreshold) {
        warnings.add(
          GlucoseWarning(
            type: WarningType.low,
            title: "Low glucose",
            options: answersForLowGlucose,
            correctOption: correctAnswerForLowGlucose,
            time: prediction.x,
          ),
        );
      } else if (prediction.y >= patientController.patient.highThreshold) {
        warnings.add(
          GlucoseWarning(
            type: WarningType.veryHigh,
            title: "Very high glucose",
            options: answersForVeryHighGlucose,
            correctOption: correctAnswerForVeryHighGlucose,
            time: prediction.x,
          ),
        );
      } else if (prediction.y >= patientController.patient.normalThreshold) {
        warnings.add(
          GlucoseWarning(
            type: WarningType.high,
            title: "High glucose",
            options: answersForHighGlucose,
            correctOption: correctAnswerForHighGlucose,
            time: prediction.x,
          ),
        );
      }
    }
  }
}
