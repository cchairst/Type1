import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:uh_t1d_tutor/controllers/glucose_simulation_controller.dart';
import 'package:uh_t1d_tutor/controllers/patient_controller.dart';
import 'package:uh_t1d_tutor/models/answer_model.dart';
import '../models/glucose_warning_model.dart';

class ImprovedGlucoseSimulation extends StatefulWidget {
  const ImprovedGlucoseSimulation({super.key});

  @override
  State<ImprovedGlucoseSimulation> createState() => _ImprovedGlucoseSimulationState();
}

class _ImprovedGlucoseSimulationState extends State<ImprovedGlucoseSimulation> 
    with SingleTickerProviderStateMixin {
  bool loading = true;
  GlucoseSimulationController glucoseController = GlucoseSimulationController();
  PatientController patientController = PatientController();

  // Game state
  String selectedAnswer = "";
  int selectedAnswerGlucoseEffect = 0;
  int selectedAnswerEffectTime = 0;
  List<GlucoseWarning> warnings = [];
  List<FlSpot> glucosePredictions = [];
  
  // Scoring & Stats
  int score = 0;
  int correctAnswers = 0;
  int totalAnswers = 0;
  int timeInRange = 0;
  int iteration = 0;
  String lastFeedback = "";
  bool showFeedback = false;
  bool lastAnswerCorrect = false;
  
  // Animation
  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      duration: const Duration(milliseconds: 1000),
      vsync: this,
    )..repeat(reverse: true);
    _pulseAnimation = Tween<double>(begin: 1.0, end: 1.05).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
    initControllers().then((_) => setState(() => loading = false));
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  Future<void> initControllers() async {
    await patientController.init();
    await glucoseController.init(patientController);
    setState(() {
      glucosePredictions = glucoseController.getPredictionsList();
      warnings = glucoseController.getWarningsList();
    });
  }

  void nextIterationHandler({int affectGlucose = 0, int affectInTime = 0}) {
    glucoseController.nextIterationOfPredictions(
      patientController,
      affectGlucose,
      affectInTime,
    );

    setState(() {
      warnings = glucoseController.getWarningsList();
      glucosePredictions = glucoseController.getPredictionsList();
      iteration++;
      
      // Check if current glucose is in range for scoring
      if (glucosePredictions.isNotEmpty) {
        double currentGlucose = glucosePredictions.first.y;
        if (currentGlucose >= patientController.patient.lowThreshold &&
            currentGlucose <= patientController.patient.normalThreshold) {
          timeInRange++;
          score += 10;
        }
      }
    });
  }

  void answerSelectionHandler(Answer newSelectedAnswer, String correctAnswer) {
    if (newSelectedAnswer.text != selectedAnswer) {
      // First click - select answer and show preview
      setState(() {
        selectedAnswer = newSelectedAnswer.text;
        selectedAnswerGlucoseEffect = newSelectedAnswer.affectGlucose;
        selectedAnswerEffectTime = newSelectedAnswer.affectInTime;
      });
    } else {
      // Second click - confirm answer
      bool isCorrect = newSelectedAnswer.text == correctAnswer;
      
      setState(() {
        totalAnswers++;
        if (isCorrect) {
          correctAnswers++;
          score += 50;
          lastFeedback = "✅ Correct! Great decision!";
          lastAnswerCorrect = true;
        } else {
          lastFeedback = "❌ Not quite. The better choice was: $correctAnswer";
          lastAnswerCorrect = false;
        }
        showFeedback = true;
        selectedAnswer = "";
        selectedAnswerGlucoseEffect = 0;
        selectedAnswerEffectTime = 0;
      });

      // Apply the effect and move to next iteration
      nextIterationHandler(
        affectGlucose: newSelectedAnswer.affectGlucose,
        affectInTime: newSelectedAnswer.affectInTime,
      );
      
      // Hide feedback after delay
      Future.delayed(const Duration(seconds: 2), () {
        if (mounted) {
          setState(() => showFeedback = false);
        }
      });
    }
  }

  Color _getGlucoseZoneColor(double glucose) {
    if (glucose < patientController.patient.lowThreshold) {
      return const Color(0xFFEF4444); // Red - low
    } else if (glucose <= patientController.patient.normalThreshold) {
      return const Color(0xFF10B981); // Green - target
    } else if (glucose <= patientController.patient.highThreshold) {
      return const Color(0xFFF59E0B); // Yellow - high
    } else {
      return const Color(0xFFEF4444); // Red - very high
    }
  }

  String _getGlucoseStatus(double glucose) {
    if (glucose < patientController.patient.lowThreshold) {
      return "LOW - Action needed!";
    } else if (glucose <= patientController.patient.normalThreshold) {
      return "In Target Range ✓";
    } else if (glucose <= patientController.patient.highThreshold) {
      return "HIGH - Monitor closely";
    } else {
      return "VERY HIGH - Action needed!";
    }
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          IconButton(
            onPressed: () => Navigator.pop(context),
            icon: const Icon(Icons.arrow_back_ios, color: Colors.white70),
            style: IconButton.styleFrom(
              backgroundColor: Colors.white.withOpacity(0.1),
            ),
          ),
          const Spacer(),
          const Text('🩺', style: TextStyle(fontSize: 24)),
          const SizedBox(width: 8),
          Text(
            'Glucose Simulation',
            style: GoogleFonts.poppins(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          const Spacer(),
          _buildScoreChip(),
        ],
      ),
    );
  }

  Widget _buildScoreChip() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(0.2)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Text('⭐', style: TextStyle(fontSize: 18)),
          const SizedBox(width: 8),
          Text(
            '$score',
            style: GoogleFonts.poppins(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatsBar() {
    double accuracy = totalAnswers > 0 ? (correctAnswers / totalAnswers * 100) : 0;
    
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.1),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _StatItem(
            icon: '🎯',
            label: 'Accuracy',
            value: '${accuracy.toStringAsFixed(0)}%',
          ),
          _StatItem(
            icon: '✅',
            label: 'Correct',
            value: '$correctAnswers/$totalAnswers',
          ),
          _StatItem(
            icon: '⏱️',
            label: 'Time in Range',
            value: '$timeInRange',
          ),
          _StatItem(
            icon: '🔄',
            label: 'Iteration',
            value: '$iteration',
          ),
        ],
      ),
    );
  }

  Widget _buildCurrentGlucoseDisplay() {
    if (glucosePredictions.isEmpty) return const SizedBox();
    
    double currentGlucose = glucosePredictions.first.y;
    Color zoneColor = _getGlucoseZoneColor(currentGlucose);
    String status = _getGlucoseStatus(currentGlucose);
    
    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: zoneColor.withOpacity(0.5), width: 2),
      ),
      child: Row(
        children: [
          ScaleTransition(
            scale: warnings.isNotEmpty ? _pulseAnimation : const AlwaysStoppedAnimation(1.0),
            child: Container(
              width: 80,
              height: 80,
              decoration: BoxDecoration(
                color: zoneColor.withOpacity(0.2),
                shape: BoxShape.circle,
                border: Border.all(color: zoneColor, width: 3),
              ),
              child: Center(
                child: Text(
                  currentGlucose.toStringAsFixed(0),
                  style: GoogleFonts.poppins(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    color: zoneColor,
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(width: 20),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Current Glucose',
                  style: GoogleFonts.poppins(
                    fontSize: 14,
                    color: Colors.white60,
                  ),
                ),
                Text(
                  '${currentGlucose.toStringAsFixed(0)} mg/dL',
                  style: GoogleFonts.poppins(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                Text(
                  status,
                  style: GoogleFonts.poppins(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: zoneColor,
                  ),
                ),
              ],
            ),
          ),
          if (warnings.isEmpty)
            ElevatedButton.icon(
              onPressed: () => nextIterationHandler(),
              icon: const Icon(Icons.skip_next),
              label: const Text('Next Hour'),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF10B981),
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildGlucoseChart() {
    List<FlSpot> chartData = [...glucosePredictions];
    
    // Apply preview effect if answer is selected
    if (selectedAnswer.isNotEmpty) {
      for (int x = 0; x < chartData.length; x++) {
        if (chartData[x].x == selectedAnswerEffectTime.toDouble()) {
          chartData[x] = FlSpot(
            chartData[x].x,
            chartData[x].y + selectedAnswerGlucoseEffect,
          );
        }
      }
    }
    
    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                '📈 Glucose Forecast',
                style: GoogleFonts.poppins(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                ),
              ),
              if (selectedAnswer.isNotEmpty)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                  decoration: BoxDecoration(
                    color: const Color(0xFF3B82F6).withOpacity(0.2),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    '👁️ Preview Mode',
                    style: GoogleFonts.poppins(
                      fontSize: 12,
                      color: const Color(0xFF60A5FA),
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 16),
          SizedBox(
            height: 200,
            child: LineChart(
              LineChartData(
                minY: 0,
                maxY: 300,
                gridData: FlGridData(
                  show: true,
                  drawVerticalLine: false,
                  horizontalInterval: 50,
                  getDrawingHorizontalLine: (value) {
                    return FlLine(
                      color: Colors.white.withOpacity(0.1),
                      strokeWidth: 1,
                    );
                  },
                ),
                titlesData: FlTitlesData(
                  topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  leftTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      interval: 100,
                      reservedSize: 40,
                      getTitlesWidget: (value, _) {
                        return Text(
                          value.toInt().toString(),
                          style: GoogleFonts.poppins(
                            fontSize: 10,
                            color: Colors.white60,
                          ),
                        );
                      },
                    ),
                  ),
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      interval: 60,
                      getTitlesWidget: (value, _) {
                        final hour = (value / 60).round();
                        return Text(
                          '+${hour}h',
                          style: GoogleFonts.poppins(
                            fontSize: 10,
                            color: Colors.white60,
                          ),
                        );
                      },
                    ),
                  ),
                ),
                borderData: FlBorderData(show: false),
                lineBarsData: [
                  // Original line (if previewing)
                  if (selectedAnswer.isNotEmpty)
                    LineChartBarData(
                      spots: glucosePredictions,
                      isCurved: true,
                      color: Colors.white.withOpacity(0.3),
                      barWidth: 2,
                      dotData: const FlDotData(show: false),
                      dashArray: [5, 5],
                    ),
                  // Main/preview line
                  LineChartBarData(
                    spots: chartData,
                    isCurved: true,
                    color: selectedAnswer.isNotEmpty 
                        ? const Color(0xFF3B82F6) 
                        : Colors.white,
                    barWidth: 3,
                    dotData: const FlDotData(show: false),
                    belowBarData: BarAreaData(
                      show: true,
                      color: (selectedAnswer.isNotEmpty 
                          ? const Color(0xFF3B82F6) 
                          : Colors.white).withOpacity(0.1),
                    ),
                  ),
                ],
                rangeAnnotations: RangeAnnotations(
                  horizontalRangeAnnotations: [
                    HorizontalRangeAnnotation(
                      y1: 0,
                      y2: patientController.patient.lowThreshold.toDouble(),
                      color: const Color(0xFFEF4444).withOpacity(0.15),
                    ),
                    HorizontalRangeAnnotation(
                      y1: patientController.patient.lowThreshold.toDouble(),
                      y2: patientController.patient.normalThreshold.toDouble(),
                      color: const Color(0xFF10B981).withOpacity(0.15),
                    ),
                    HorizontalRangeAnnotation(
                      y1: patientController.patient.normalThreshold.toDouble(),
                      y2: patientController.patient.highThreshold.toDouble(),
                      color: const Color(0xFFF59E0B).withOpacity(0.15),
                    ),
                    HorizontalRangeAnnotation(
                      y1: patientController.patient.highThreshold.toDouble(),
                      y2: 300,
                      color: const Color(0xFFEF4444).withOpacity(0.15),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          // Legend
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _LegendItem(color: const Color(0xFFEF4444), label: 'Low/High'),
              const SizedBox(width: 16),
              _LegendItem(color: const Color(0xFF10B981), label: 'Target'),
              const SizedBox(width: 16),
              _LegendItem(color: const Color(0xFFF59E0B), label: 'Elevated'),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildWarningModal(GlucoseWarning warning) {
    Color warningColor;
    String warningEmoji;
    
    switch (warning.type) {
      case WarningType.low:
        warningColor = const Color(0xFFEF4444);
        warningEmoji = '⚠️';
        break;
      case WarningType.high:
        warningColor = const Color(0xFFF59E0B);
        warningEmoji = '📈';
        break;
      case WarningType.veryHigh:
        warningColor = const Color(0xFFEF4444);
        warningEmoji = '🚨';
        break;
    }
    
    return Container(
      color: Colors.black54,
      child: Center(
        child: Container(
          margin: const EdgeInsets.all(24),
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Color(0xFF1E293B),
                Color(0xFF0F172A),
              ],
            ),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: warningColor.withOpacity(0.5), width: 2),
            boxShadow: [
              BoxShadow(
                color: warningColor.withOpacity(0.3),
                blurRadius: 30,
                spreadRadius: 5,
              ),
            ],
          ),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Header
                Row(
                  children: [
                    Text(warningEmoji, style: const TextStyle(fontSize: 32)),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            warning.title.toUpperCase(),
                            style: GoogleFonts.poppins(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: warningColor,
                            ),
                          ),
                          Text(
                            'Alert in ${warning.time.toInt()} minutes',
                            style: GoogleFonts.poppins(
                              fontSize: 14,
                              color: Colors.white70,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                
                // Question
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: warningColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: warningColor.withOpacity(0.3)),
                  ),
                  child: Text(
                    'What action should you take to manage this situation?',
                    style: GoogleFonts.poppins(
                      fontSize: 16,
                      color: Colors.white,
                      fontWeight: FontWeight.w500,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
                const SizedBox(height: 20),
                
                // Answer options
                ...warning.options.map((option) {
                  bool isSelected = option.text == selectedAnswer;
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: Material(
                      color: isSelected 
                          ? const Color(0xFF3B82F6).withOpacity(0.2)
                          : Colors.white.withOpacity(0.05),
                      borderRadius: BorderRadius.circular(12),
                      child: InkWell(
                        onTap: () => answerSelectionHandler(option, warning.correctOption),
                        borderRadius: BorderRadius.circular(12),
                        child: Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: isSelected 
                                  ? const Color(0xFF3B82F6)
                                  : Colors.white.withOpacity(0.2),
                              width: isSelected ? 2 : 1,
                            ),
                          ),
                          child: Row(
                            children: [
                              Container(
                                width: 24,
                                height: 24,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: isSelected 
                                      ? const Color(0xFF3B82F6)
                                      : Colors.transparent,
                                  border: Border.all(
                                    color: isSelected 
                                        ? const Color(0xFF3B82F6)
                                        : Colors.white54,
                                    width: 2,
                                  ),
                                ),
                                child: isSelected 
                                    ? const Icon(Icons.check, size: 16, color: Colors.white)
                                    : null,
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Text(
                                  option.text,
                                  style: GoogleFonts.poppins(
                                    fontSize: 14,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                }),
                
                if (selectedAnswer.isNotEmpty) ...[
                  const SizedBox(height: 16),
                  Text(
                    '👆 Tap again to confirm your choice',
                    style: GoogleFonts.poppins(
                      fontSize: 12,
                      color: const Color(0xFF60A5FA),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildFeedbackOverlay() {
    return AnimatedOpacity(
      opacity: showFeedback ? 1.0 : 0.0,
      duration: const Duration(milliseconds: 300),
      child: Container(
        margin: const EdgeInsets.all(16),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: lastAnswerCorrect 
              ? const Color(0xFF10B981).withOpacity(0.9)
              : const Color(0xFFEF4444).withOpacity(0.9),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Row(
          children: [
            Text(
              lastAnswerCorrect ? '✅' : '❌',
              style: const TextStyle(fontSize: 24),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                lastFeedback,
                style: GoogleFonts.poppins(
                  fontSize: 14,
                  color: Colors.white,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return Scaffold(
        body: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFF0F172A), Color(0xFF1E293B), Color(0xFF0F172A)],
            ),
          ),
          child: const Center(
            child: CircularProgressIndicator(color: Color(0xFF10B981)),
          ),
        ),
      );
    }

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF0F172A), Color(0xFF1E293B), Color(0xFF0F172A)],
          ),
        ),
        child: SafeArea(
          child: Stack(
            children: [
              Column(
                children: [
                  _buildHeader(),
                  _buildStatsBar(),
                  _buildCurrentGlucoseDisplay(),
                  Expanded(child: _buildGlucoseChart()),
                ],
              ),
              if (warnings.isNotEmpty)
                _buildWarningModal(warnings.first),
              if (showFeedback)
                Positioned(
                  bottom: 0,
                  left: 0,
                  right: 0,
                  child: _buildFeedbackOverlay(),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _StatItem extends StatelessWidget {
  final String icon;
  final String label;
  final String value;

  const _StatItem({
    required this.icon,
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(icon, style: const TextStyle(fontSize: 20)),
        const SizedBox(height: 4),
        Text(
          value,
          style: GoogleFonts.poppins(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        Text(
          label,
          style: GoogleFonts.poppins(
            fontSize: 10,
            color: Colors.white60,
          ),
        ),
      ],
    );
  }
}

class _LegendItem extends StatelessWidget {
  final Color color;
  final String label;

  const _LegendItem({required this.color, required this.label});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 12,
          height: 12,
          decoration: BoxDecoration(
            color: color.withOpacity(0.5),
            borderRadius: BorderRadius.circular(3),
          ),
        ),
        const SizedBox(width: 6),
        Text(
          label,
          style: GoogleFonts.poppins(
            fontSize: 10,
            color: Colors.white60,
          ),
        ),
      ],
    );
  }
}
