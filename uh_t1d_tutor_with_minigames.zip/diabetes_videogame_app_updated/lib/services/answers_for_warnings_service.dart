import 'package:flutter/services.dart' show rootBundle;
import 'package:yaml/yaml.dart';

import '../models/answer_model.dart';

class AnswersForWarnings {
  Future<List<Answer>> loadAnswers(String filter) async {
    List<Answer> answers = [];

    final yamlString = await rootBundle.loadString('assets/answers.yaml');
    final data = loadYaml(yamlString) as YamlMap;
    final warnings = data["warnings"] as YamlList;
    for (var warning in warnings) {
      if (warning["warningType"] == filter) {
        final options = warning["options"] as YamlList;
        for (var option in options) {
          answers.add(
            Answer(
              text: option["text"] as String,
              affectGlucose: option["affectGlucose"] as int,
              affectInTime: option["affectInTime"] as int,
            ),
          );
        }
      }
    }

    return answers;
  }
}
